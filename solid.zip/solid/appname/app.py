from flask import *
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:kgisl@localhost/solid'
app.config['SECRET_KEY'] = "random string"

db = SQLAlchemy(app)

@app.route("/login")
def login():
	return render_template("user_login.html")

@app.route("/registration")
def registration():
	return render_template("reg_success.html")

@app.route("/signup")
def signup():
	return render_template("signup.html")


@app.route("/adminlogin")
def login1():
	return render_template("login.html")
@app.route("/input")
def user_text():
	return render_template("user_text.html")
	
@app.route("/dashboard")
def dashboard():
	return render_template("dashboard.html")
@app.route("/addingofficer")
def addingofficer():
	return render_template("add_officer.html")	
	
@app.route("/enquiry")
def enquiry():
	return render_template("enquiry.html")
@app.route("/incharge")
def incharge():
	return render_template("incharge.html")	
@app.route("/notification")
def notification():
	return render_template("notification.html")	
@app.route("/officerdetail")
def officerdetail():
	return render_template("officer_detail.html")	



class register(db.Model):
	First_Name=db.Column(db.String)
	Last_Name=db.Column(db.String)
	Address=db.Column(db.String)
	City=db.Column(db.String)
	State=db.Column(db.String)
	Zip=db.Column(db.Integer)
	Phone_Number=db.Column(db.Integer)
	Email_Address=db.Column(db.String)
	username=db.Column('username',db.String,primary_key=True)
	password=db.Column(db.String)
	confirm_password=db.Column(db.String)
	
	def __init__(self,First_Name,Last_Name,Address,City,State,Zip,Phone_Number,Email_Address,username,password,confirm_password):
		self.First_Name=First_Name
		self.Last_Name=Last_Name
		self.Address=Address
		self.City=City
		self.State=State
		self.Zip=Zip
		self.Phone_Number=Phone_Number
		self.Email_Address=Email_Address
		self.username=user_name
		self.password=password
		self.confirm_password=confirm_password
		
		
	@app.route("/register_db",methods=["GET","POST"])
	def register_db():
		if request.method == 'POST':
			if not request.form['First_Name'] or not request.form['Last_Name'] or not request.form['Address'] or not request.form['City'] or not request.form['State']or not request.form['Zip']or not request.form['Phone_Number']or not request.form['Email_Address']or not request.form['username']or not request.form['password']or not request.form['confirm_password']:
				flash("Error")
			else:
				student=register(request.form['First_Name'],request.form['Last_Name'],request.form['Address'],request.form['City'],request.form['State'],request.form['Zip'],request.form['Phone_Number'],request.form['Email_Address'],request.form['username'],request.form['password'],request.form['confirm_password'])
				db.session.add(user)
				db.session.commit()
			return redirect(url_for('register'))
		return render_template("signup.html")


if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
