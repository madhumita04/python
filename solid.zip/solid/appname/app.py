from flask import *
from flask_sqlalchemy import SQLAlchemy

from flask_googlemaps import GoogleMaps

from flask_googlemaps import Map

app = Flask(__name__)

GoogleMaps(app, key="my-key")

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:kgisl@localhost/solidwastemanagement'
app.config['SECRET_KEY'] = "random string"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False


db = SQLAlchemy(app)

@app.route("/login")
def login():
	return render_template("user_login.html")

@app.route("/registerform")
def registerform():
	return render_template("signup.html")

@app.route("/registration")
def registration():
	return render_template("reg_success.html")


@app.route("/adminlogin")
def login1():
	return render_template("login.html")

@app.route("/input")
def user_text():
	return render_template("user_text.html")
	
@app.route("/dashboard")
def dashboard():
	return render_template("dashboard.html")

@app.route("/add_officer")
def addingofficer():
	return render_template("add_officer.html")	
	
@app.route("/enquiry")
def enquiry():
	return render_template("enquiry.html")

@app.route("/incharge")
def incharge():
	return render_template("incharge.html")	

@app.route("/notification")
def notification():
	return render_template("notification.html")	

@app.route("/officerdetail")
def officerdetail():
	return render_template("officer_detail.html")	
	
	
	
@app.route('/map', methods=["GET"])
def my_map():
    mymap = Map(

                identifier="view-side",

                varname="mymap",

                style="height:720px;width:1100px;margin:0;", # hardcoded!

                lat=37.4419, # hardcoded!

                lng=-122.1419, # hardcoded!

                zoom=15,

                markers=[(37.4419, -122.1419)] # hardcoded!

            )

    return render_template('map.html', mymap=mymap)



class register(db.Model):
	First_Name=db.Column(db.String)
	Last_Name=db.Column(db.String)
	Address=db.Column(db.String)
	City=db.Column(db.String)
	State=db.Column(db.String)
	Zip=db.Column(db.Integer)
	Phone_Number=db.Column(db.Integer)
	Email_Address=db.Column(db.String)
	Username=db.Column('username',db.String,primary_key=True)
	Password=db.Column(db.String)
	confirm_password=db.Column(db.String)
	
	def __init__(self,First_Name,Last_Name,Address,City,State,Zip,Phone_Number,Email_Address,User_name,Password,Confirm_password):
		self.First_Name=First_Name
		self.Last_Name=Last_Name
		self.Address=Address
		self.City=City
		self.State=State
		self.Zip=Zip
		self.Phone_Number=Phone_Number
		self.Email_Address=Email_Address
		self.User_name=User_name
		self.Password=Password
		self.Confirm_password=Confirm_password
		
		
	@app.route("/register_db",methods=["GET","POST"])
	def register_db():
		if request.method == 'POST':
			if not request.form['First_Name'] or not request.form['Last_Name'] or not request.form['Address'] or not request.form['City'] or not request.form['State']or not request.form['Zip']or not request.form['Phone_Number']or not request.form['Email_Address']or not request.form['User name']or not request.form['Password']or not request.form['Confirm_password']:
				flash("Error")
			else:
				user=register(request.form['First_Name'],request.form['Last_Name'],request.form['Address'],request.form['City'],request.form['State'],request.form['Zip'],request.form['Phone_Number'],request.form['Email_Address'],request.form['Username'],request.form['Password'],request.form['Confirm_password'])
				db.session.add(user)
				db.session.commit()
			return redirect(url_for('login'))
		return render_template("user_login.html")


class add_officer(db.Model):
	Name=db.Column(db.String)
	Designation=db.Column(db.String)
	Office_address=db.Column(db.String)
	Mail_id=db.Column('Mail_id',db.String,primary_key=True)
	
	def __init__(self,Name,Designation,Office_address,Mail_id):
		self.Name=Name
		self.Designation=Designation
		self.Office_address=office_address
		self.Mail_id=Mail_id
	
@app.route("/add_officer_db",methods=["GET","POST"])
def add_officer_db():
	if request.method == 'POST':
		if not request.form['Name'] or not request.form['Designation'] or not request.form['Office_address'] or not request.form['Mail_id']:
			flash("error")
		else:
			officer=add_officer(request.form['Name'],request.form['Designation'],request.form['Office_address'],request.form['Mail_id'])
			db.session.add(officer)
			db.session.commit()
			return redirect(url_for('add_officer'))
		return render_template("add_officer.html")
		
class enquiry(db.Model):
	Name=db.Column(db.String)
	Mail_id=db.Column('Mail_id',db.String,primary_key=True)
	Area=db.Column(db.String)
	Subject=db.Column(db.String)
	Query=db.Column(db.String)

def __init__(self,Name,Mail_id,Area,Subject,Query):
		self.Name=Name
		self.Mail_id=Mail_id
		self.Area=Area
		self.Subject=Subject
		self.Query=Query
		
@app.route("/enquiry_db",methods=["GET","POST"])
def enquiry_db():
	if request.method == 'POST':
		if not request.form['Name'] or not request.form['Mail_id'] or not request.form['Area'] or not request.form['Subject'] or not request.form['Query']:
			flash("error")
		else:
			msg=add_officer(request.form['Name'],request.form['Mail_id'],request.form['Area'],request.form['Subject'], request.form['Query'])
			db.session.add(msg)
			db.session.commit()
			return redirect(url_for('enquiry'))
		return render_template("enquiry.html")

with app.app_context():
    db.create_all()

if __name__ == '__main__':
	db.create_all()
	app.run(debug=True, use_reloader=True)

